﻿namespace Orcamentaria.APIGetaway.Domain.DTOs
{
    public class RequestParamDTO
    {
        public string ParamName { get; set; }
        public string ParamValue { get; set; }
    }
}
